This folder contains two scraping examples:
- the Wikipedia example uses Python library which simplifies the operations,
- the IMDB example is scraped 'by hand' using the Beautiful Soup library.
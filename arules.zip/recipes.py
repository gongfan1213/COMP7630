from pprint import pprint
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules

'''
The dataset recipes.txt has been obtained from https://www.kaggle.com/datasets/kaggle/recipe-ingredients-dataset with a little of processing as follows:
- train.json and test.json have been downloaded from the URL above
- the following Python script is run to merge train.json and test.json in order to generate the recipes.txt file
import json
ftrain = open('train.json', 'r')
ftest = open('test.json', 'r')
train = json.load(ftrain)
test = json.load(ftest)
ftrain.close()
ftest.close()
lst = train + test #now it is a list of dict
lst = [ [d['cuisine']] + d['ingredients'] for d in lst if 'cuisine' in d ] #now it is a list of lists
fout = open('recipes.txt', 'w')
for recipe in lst: print(';'.join(recipe), file=fout, end='\n')
fout.close()
'''

#load dataset of recipes from file (every line is a list of cuisine+ingredients separated by ';')
dataset = []
f = open('recipes.txt', 'r')
for line in f:
    dataset.append(line.split(';'))
f.close()

#print some info about the dataset for reporting purposes
print('*** Dataset ***')
print(f'A total of {len(dataset)} recipes have been loaded. Herebelow are the first 10 recipes in the dataset:')
for i,r in enumerate(dataset[:10]):
    print(f'{i+1}. {";".join(r)}', end='')
print('...')
print('***************')
print()

#convert dataset to Pandas onehot encoding
te = TransactionEncoder()
onehot = te.fit(dataset).transform(dataset)
df = pd.DataFrame(onehot, columns=te.columns_) #you can print df to see the onehot format!!!

#run apriori to discover all itemsets with support>=500 as absolute value and max_len=4 (so algorithm does not try to compute itemsets with length>4)
#if this step is too slow for your computer, increase 500/n to 1000/n or a larger value
n = len(dataset)
fis = apriori(df, min_support=500/n, max_len=4, use_colnames=True) #there should be 483 itemsets with minsup=500/n

#print the 20 itemsets with largest support and length>=2
fis['length'] = fis['itemsets'].apply(lambda x: len(x)) #add the column 'length' to the Pandas dataframe fis
fis_filtered = fis[fis.length>=2].sort_values(by='support', ascending=False)
print('*** Top 20 itemsets by support, with length>=2 and minsup=500 (as absolute value) ***')
pprint(fis_filtered[:20])
print('*************************************************************************************')
print()

#generate association rules from the frequent itemsets with minconf=50%
ar = association_rules(fis, metric='confidence', min_threshold=0.50) #there should be 84 association rules matching

#print the association rules useful for us
print('*** Top 30 association rules by lift, with minsup=500 (as absolute value) and minconf=50% ***')
pprint(ar[['antecedents','consequents','lift','support','confidence']].sort_values(by='lift', ascending=False)[:30])
print('*********************************************************************************************')
print()

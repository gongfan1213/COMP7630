from pprint import pprint
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules


#an example of dataset: any inner list is a transaction (set of items)
dataset = [['Milk', 'Onion', 'Nutmeg', 'Kidney Beans', 'Eggs', 'Yogurt'],
           ['Dill', 'Onion', 'Nutmeg', 'Kidney Beans', 'Eggs', 'Yogurt'],
           ['Milk', 'Apple', 'Kidney Beans', 'Eggs'],
           ['Milk', 'Unicorn', 'Corn', 'Kidney Beans', 'Yogurt'],
           ['Corn', 'Onion', 'Onion', 'Kidney Beans', 'Ice cream', 'Eggs']]

#obtain the universe of items (just for reporting purposes)
universe = sorted(set([ item for transaction in dataset for item in transaction ]))

#print the universe of items and the dataset of transactions
print('*** Universe of items ***')
pprint(universe)
print('*************************')
print()
print('*** Dataset of transactions ***')
pprint(dataset)
print('*******************************')
print()

#apriori function needs dataset in OneHot pandas format, so let's convert it
te = TransactionEncoder()
onehot = te.fit(dataset).transform(dataset)
df = pd.DataFrame(onehot, columns=te.columns_) #you can print df to see the onehot format!!!

#run apriori to discover all itemsets with minsup=60%
fis = apriori(df, min_support=0.6, use_colnames=True) #fis stay for "frequent itemsets"

#print the frequent itemsets
print('*** Frequent Itemsets with minsup=60% ***')
pprint(fis)
print('*****************************************')
print()

#generate association rules from the frequent itemsets with minconf=70%
ar = association_rules(fis, metric='confidence', min_threshold=0.7) #ar stay for "association rules"

#print the association rules with only the information useful for us (antecedents,consequents,support,confidence)
print('*** Association rules with minsup=60% and minconf=70% ***')
pprint(ar[['antecedents','consequents','support','confidence']])
print('*********************************************************')
print()

'''
In this example we make classification using repeated k-fold cross-validation.
We use 10 repetitions and 5 folds.
We calculate accuracy and also F1-score for two models:
- K-Nearest-Neighbor feeded with un-normalized data-matrix
- K-Nearest-Neighbor feeded with normalized data-matrix
'''

from dataset import *
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import Normalizer
from sklearn.model_selection import cross_val_score, RepeatedStratifiedKFold
import numpy as np
import matplotlib.pyplot as plt



#load the dataset and vectorize it
texts,labels = load_dataset('dataset1')
X,y = vectorize_dataset(texts,labels)

#run a KNN with K=5 on the unnormalized dataset by using cross-validation as described above
knn = KNeighborsClassifier(n_neighbors=5)
cv = RepeatedStratifiedKFold( n_splits=5, n_repeats=10, random_state=42 )
scores_wo_norm = cross_val_score(knn, X, y, cv=cv, scoring='accuracy') #5*10 accuracies obtained in data-matrix WITHOUT normalization

#normalize the data-matrix and then run KNN as above
normalizer = Normalizer()
X_normalized = normalizer.fit_transform(X)
knn = KNeighborsClassifier(n_neighbors=5)
cv = RepeatedStratifiedKFold( n_splits=5, n_repeats=10, random_state=42 )
scores_w_norm = cross_val_score(knn, X_normalized, y, cv=cv, scoring='accuracy') #5*10 accuracies obtained in data-matrix WITH normalization

#print means and standard deviations of the accuracies
print(f'ACCURACY WITHOUT NORMALIZATION = {scores_wo_norm.mean():.2f} +/- {scores_wo_norm.std():.2f}')
print(f'ACCURACY WITH    NORMALIZATION = {scores_w_norm.mean():.2f} +/- {scores_w_norm.std():.2f}')

#make a plot and show it
plt.figure()
plt.clf()
tick_labels = ['Un-normalized', 'Normalized']
means = [scores_wo_norm.mean(), scores_w_norm.mean()]
stds = [scores_w_norm.std(), scores_w_norm.std()]
plt.bar(x=range(2),
        height=means,
        yerr=stds)
plt.xticks(range(2), tick_labels)
plt.ylabel('Accuracy')
plt.title('K-Nearest-Neighbor on un-normalized and normalized dataset')
plt.tight_layout()
plt.show()
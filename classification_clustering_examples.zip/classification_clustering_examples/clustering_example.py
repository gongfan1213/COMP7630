from dataset import *
from sklearn.cluster import KMeans
from sklearn.preprocessing import Normalizer
from sklearn.metrics import silhouette_score
import numpy as np



#load the dataset and vectorize it
texts,labels = load_dataset('dataset1')
X,y = vectorize_dataset(texts,labels)
#since we are doing clustering, we are not going to use 'labels' and 'y', but only 'texts' and 'X'

#normalize the data-matrix
normalizer = Normalizer()
X = normalizer.fit_transform(X)

#get the shape of the data-matrix
n_samples, n_features = X.shape

#we try to cluster with the following number of clusters {2,3,4}
#we use simple settings for K-Means because they will be useful later in the course:
#   - init is a numpy matrix of shape (n_clusters, n_features) and it is the initial setting of centroid ... it is also possible to set at the string 'random', but implemented like this give you full control for possible further modifications
#   - n_init=1, means that KMeans is executed only one time ... useful for possible further modification
k_list = [2,3,4]
for k in k_list:
    #we set initial centroid by taking each feature as a random value from the samples in the data-matrix (in this way we do not have to care about too large or too small values
    initial_centroids = np.empty( (k,n_features), dtype=X.dtype )
    for i in range(k):
        for j in range(n_features):
            r = np.random.randint(n_samples) #an random index in [0,n_samples)
            initial_centroids[i,j] = X[r,j] #take features j but from a random sample
    #initialize k-means with the hyperparameters decided
    km = KMeans(n_clusters=k, init=initial_centroids, n_init=1) #if you are lazy, you can call simply KMeans(n_clusters=k) avoiding the manual random initialization of the centroids above
    #execute k-means
    km.fit(X)
    #get the labels of the clusters assigned to the samples
    labels = km.labels_
    #get the inertia of the clustering
    inertia = km.inertia_
    #compute silhouette score
    silhouette = silhouette_score(X,labels)
    #some printing
    print()
    print(f'**************************')
    print(f'*** K-MEANS WITH K={k} ***')
    print(f'**************************')
    #print the inertia of the clustering
    print('--- SILHOUETTE SCORE (to be maximized) ---')
    print(silhouette)
    #print the inertia of the clustering
    print('--- INERTIA (to be minimized) ---')
    print(inertia)
    #print the labels assigned to each sample
    print('--- LABELS ASSIGNED TO THE SAMPLES ---')
    print(labels)

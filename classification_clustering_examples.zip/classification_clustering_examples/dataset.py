#function for loading the dataset
#  assumes that inside 'directory' there will be .txt files whose name is <label-of-the-text-in-the-file> + a identifier separated by an underscore
#  returns a tuple formed by two lists of the same length: list of texts, list of labels
def load_dataset(directory):
    #import libraries for useful function
    from glob import glob
    #define empty lists which will be filled later
    texts = []
    labels = []
    #iterate thru all files in the dataset folder and add entries to texts,labels
    for filename in glob(f'{directory}/*.txt'):
        #the content of the file is the text
        with open(filename,'r',encoding='utf-8') as f:
            text = f.read()
        texts.append(text)
        #part of the name of the file is the label
        left, right = len(f'{directory}/'), filename.rindex('_') #left and right indexes where to cut the filename to have the label
        label = filename[left:right]
        labels.append(label)
    #return both texts and labels
    return texts,labels



#function for transforming a text dataset (texts,labels) into a data-matrix 'X' + a target vector 'y' as required by Scikit Learn
#  assumes texts,labels are as obtained by 'load_dataset'
#  returns a tuple formed by: numpy data-matrix X, numpy label-vector y
#  Note: the vectorization is done by using Spacy and its word2vec embeddings, labels are assigned to integer ids 0,1,2,...
def vectorize_dataset(texts, labels):
    #import libraries and load Spacy model
    import spacy
    import numpy as np
    nlp = spacy.load('en_core_web_md')
    #set variables for the shape of the data-matrix
    k = len(texts) #assumed same as len(labels)
    n = 300 #we know number of features is 300 for the vectors returned by 'en_core_web_md'
    #allocate memory for the data-matrix and the labels vector
    X = np.empty( (k,n), dtype='float32' ) #we know float32 is the type of the vectors returned by 'en_core_web_md'
    y = np.empty( k, dtype='int' )
    #get the unique labels in the dataset
    unique_labels = np.unique(labels).tolist()
    #iterate thru all the text+label in the dataset and set, one-by-one, the rows of X and the entries in y
    i = 0
    for text,label in zip(texts,labels):
        doc = nlp(text)
        X[i] = doc.vector
        y[i] = unique_labels.index(label)
        i += 1
    #return the data-matrix and the labels vector
    return X,y
#this module contains our functions for loading and vectorizing the dataset
from dataset import *

#these two functions are for splitting dataset at the beginning and compute accuracy score at the end
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

#these are four classifiers we will use and compare to each other
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier



#load the dataset and vectorize it
texts,labels = load_dataset('dataset1')
X,y = vectorize_dataset(texts,labels)

#split the dataset into training-set (80%) + test-set (20%)... use shuffling and stratification (i.e. preserve proportion of labels in both sets)
X_train, X_test, y_train, y_test = train_test_split( X, y, test_size=0.2, shuffle=True, stratify=y, random_state=42)

#train a classifier based on Logistic Regression (a linear classification model) with default parameters
clf = LogisticRegression()
clf.fit(X_train, y_train)
#make prediction on the test set using the trained classifier, calculate accuracy and print
y_pred = clf.predict(X_test)
acc = accuracy_score(y_test, y_pred)
print(f'LogisticRegression accuracy = {acc}')

#train a classifier based on Support Vector Machine Classifier with default parameters (but generally it is better to tune C and gamma)
clf = SVC()
clf.fit(X_train, y_train)
#make prediction on the test set using the trained classifier, calculate accuracy and print
y_pred = clf.predict(X_test)
acc = accuracy_score(y_test, y_pred)
print(f'SVC accuracy = {acc}')

#train a classifier based on Random Forest with 100 decision trees, each one with a max depth of 4 (max_depth is important to set because without depth the model will overfit)
clf = RandomForestClassifier(n_estimators=100, max_depth=4)
clf.fit(X_train, y_train)
#make prediction on the test set using the trained classifier, calculate accuracy and print
y_pred = clf.predict(X_test)
acc = accuracy_score(y_test, y_pred)
print(f'RandomForestClassifier accuracy = {acc}')

#train a classifier based on MultiLayer Perceptron (a feed forward neural network) with: 2 inner layers of size 100,50, activation function = relu, solver = adam
clf = MLPClassifier(hidden_layer_sizes=(100,50), activation='relu', solver='adam' )
clf.fit(X_train, y_train)
#make prediction on the test set using the trained classifier, calculate accuracy and print
y_pred = clf.predict(X_test)
acc = accuracy_score(y_test, y_pred)
print(f'MLPClassifier accuracy = {acc}')
